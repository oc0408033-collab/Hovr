package com.hovr.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        fun btn(t: String, c: Int, f: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.WHITE); setBackgroundColor(c); setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams((260 * d).toInt(), (52 * d).toInt()).apply { topMargin = (12 * d).toInt() }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.parseColor("#0E0F1A"))
            addView(ImageView(context).apply { setImageResource(R.mipmap.ic_launcher); layoutParams = LinearLayout.LayoutParams((110 * d).toInt(), (110 * d).toInt()) })
            addView(TextView(context).apply { text = "Hovr"; textSize = 38f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
            addView(TextView(context).apply { text = "Watch in a floating window.\nPlay games. Keep watching."; setTextColor(Color.parseColor("#B8B8D0")); gravity = Gravity.CENTER })
            addView(btn("▶  Start floating player", Color.parseColor("#5B2EFF")) { start() })
            addView(btn("✕  Stop", Color.parseColor("#2A2B3D")) { stopService(Intent(this@MainActivity, FloatService::class.java)) })
        }
        setContentView(col)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" for Hovr, then tap Start again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, FloatService::class.java))
    }
}
