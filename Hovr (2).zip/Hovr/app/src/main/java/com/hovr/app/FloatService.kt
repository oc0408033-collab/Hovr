package com.hovr.app

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.IBinder
import android.text.InputType
import android.view.*
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*

class FloatService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var wrap: FrameLayout? = null
    private var yt: WebView? = null
    private var br: WebView? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("hovr", "Hovr", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, FloatService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, "hovr").setSmallIcon(R.drawable.ic_notif).setContentTitle("Hovr is running")
            .addAction(Notification.Action.Builder(null, "Close", stop).build()).build())
        show()
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        val noFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        val yesFocus = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        lp = WindowManager.LayoutParams(dp(300), dp(260), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, noFocus, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(80) }

        fun setFocus(on: Boolean) {
            lp.flags = if (on) yesFocus else noFocus
            wrap?.let { wm.updateViewLayout(it, lp) }
        }

        val urlBar = EditText(this).apply {
            setSingleLine(); hint = "Search Google or type a link"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            textSize = 13f; setBackgroundColor(Color.parseColor("#22233A")); setPadding(dp(10), 0, dp(10), 0)
            imeOptions = EditorInfo.IME_ACTION_GO; inputType = InputType.TYPE_TEXT_VARIATION_URI
            setOnTouchListener { v, e -> if (e.action == MotionEvent.ACTION_DOWN) { setFocus(true); v.requestFocus() }; false }
        }

        fun newWeb(start: String, onUrl: ((String) -> Unit)?) = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            CookieManager.getInstance().setAcceptCookie(true)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(v: WebView, u: String, f: android.graphics.Bitmap?) { onUrl?.invoke(u) }
            }
            webChromeClient = WebChromeClient()
            loadUrl(start)
        }
        val ytv = newWeb("https://m.youtube.com", null).also { yt = it }
        val brv = newWeb("https://www.google.com") { u -> if (!urlBar.hasFocus()) urlBar.setText(u) }.also { br = it }
        brv.visibility = View.INVISIBLE
        var cur: WebView = ytv

        val webArea = FrameLayout(this).apply {
            addView(ytv, FrameLayout.LayoutParams(-1, -1)); addView(brv, FrameLayout.LayoutParams(-1, -1))
        }

        fun go(q: String) {
            val s = q.trim(); if (s.isEmpty()) return
            val url = when {
                s.startsWith("http://") || s.startsWith("https://") -> s
                s.contains(".") && !s.contains(" ") -> "https://$s"
                else -> "https://www.google.com/search?q=" + Uri.encode(s)
            }
            brv.loadUrl(url)
        }
        urlBar.setOnEditorActionListener { v, _, _ -> go(v.text.toString()); v.clearFocus(); setFocus(false); true }

        fun tv(t: String, onClick: (() -> Unit)?) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; setPadding(dp(12), 0, dp(12), 0)
            onClick?.let { c -> setOnClickListener { c() } }
        }
        val tabYt = tv("▶ YouTube", null); val tabBr = tv("🌐 Browser", null)
        fun select(browser: Boolean) {
            cur = if (browser) brv else ytv
            ytv.visibility = if (browser) View.INVISIBLE else View.VISIBLE
            brv.visibility = if (browser) View.VISIBLE else View.INVISIBLE
            urlBar.visibility = if (browser) View.VISIBLE else View.GONE
            tabYt.setBackgroundColor(if (browser) Color.TRANSPARENT else Color.parseColor("#44FFFFFF"))
            tabBr.setBackgroundColor(if (browser) Color.parseColor("#44FFFFFF") else Color.TRANSPARENT)
        }
        tabYt.setOnClickListener { select(false) }; tabBr.setOnClickListener { select(true) }

        val label = tv("✥ Hovr", null).apply { layoutParams = LinearLayout.LayoutParams(0, -1, 1f); gravity = Gravity.CENTER_VERTICAL }
        val bar = LinearLayout(this).apply {
            setBackgroundColor(Color.parseColor("#5B2EFF")); gravity = Gravity.CENTER_VERTICAL
            addView(label)
            addView(tv("⌨") { setFocus(lp.flags == noFocus) }, LinearLayout.LayoutParams(-2, -1))
            addView(tv("◐") { wrap?.alpha = if (wrap?.alpha == 1f) 0.6f else 1f }, LinearLayout.LayoutParams(-2, -1))
            addView(tv("✕") { stopSelf() }, LinearLayout.LayoutParams(-2, -1))
        }
        val tabs = LinearLayout(this).apply {
            setBackgroundColor(Color.parseColor("#1A1B2E")); gravity = Gravity.CENTER_VERTICAL
            addView(tabYt, LinearLayout.LayoutParams(-2, -1)); addView(tabBr, LinearLayout.LayoutParams(-2, -1))
            addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
            addView(tv("◀") { if (cur.canGoBack()) cur.goBack() }, LinearLayout.LayoutParams(-2, -1))
            addView(tv("↗") { cur.url?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }, LinearLayout.LayoutParams(-2, -1))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK)
            addView(bar, LinearLayout.LayoutParams(-1, dp(38)))
            addView(tabs, LinearLayout.LayoutParams(-1, dp(34)))
            addView(urlBar, LinearLayout.LayoutParams(-1, dp(36)))
            addView(webArea, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        select(false)
        val grip = tv("◢", null).apply { setBackgroundColor(Color.parseColor("#995B2EFF")) }
        val root = FrameLayout(this).apply {
            addView(col, FrameLayout.LayoutParams(-1, -1))
            addView(grip, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.END))
        }
        wrap = root

        label.setOnTouchListener(object : View.OnTouchListener {
            var x = 0f; var y = 0f; var px = 0; var py = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { x = e.rawX; y = e.rawY; px = lp.x; py = lp.y }
                    MotionEvent.ACTION_MOVE -> { lp.x = px + (e.rawX - x).toInt(); lp.y = py + (e.rawY - y).toInt(); wm.updateViewLayout(root, lp) }
                }
                return true
            }
        })
        grip.setOnTouchListener(object : View.OnTouchListener {
            var x = 0f; var y = 0f; var pw = 0; var ph = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { x = e.rawX; y = e.rawY; pw = lp.width; ph = lp.height }
                    MotionEvent.ACTION_MOVE -> {
                        lp.width = (pw + (e.rawX - x).toInt()).coerceIn(dp(200), sw)
                        lp.height = (ph + (e.rawY - y).toInt()).coerceIn(dp(180), sh)
                        wm.updateViewLayout(root, lp)
                    }
                }
                return true
            }
        })
        wm.addView(root, lp)
    }

    override fun onDestroy() {
        yt?.destroy(); br?.destroy(); wrap?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
