package com.hovr.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*

class SearchActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        val d = resources.displayMetrics.density
        val et = EditText(this).apply {
            hint = "Search YouTube or the web"; setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        fun send() {
            val q = et.text.toString().trim()
            if (q.isNotEmpty()) startService(Intent(this, FloatService::class.java).setAction("search").putExtra("q", q))
            finish()
        }
        et.setOnEditorActionListener { _, _, _ -> send(); true }
        val btn = Button(this).apply { text = "Search"; setOnClickListener { send() } }
        val pad = (16 * d).toInt()
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
            addView(et); addView(btn)
        })
        et.requestFocus()
    }
}
