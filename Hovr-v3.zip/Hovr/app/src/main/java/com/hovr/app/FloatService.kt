package com.hovr.app

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.IBinder
import android.text.InputType
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*

class FloatService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var wrap: FrameLayout? = null
    private var colV: View? = null
    private var yt: WebView? = null
    private var br: WebView? = null
    private var fsView: View? = null
    private var fsCb: WebChromeClient.CustomViewCallback? = null
    private var saved = IntArray(4)
    private var onUi: (() -> Unit)? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("hovr", "Hovr", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, FloatService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, "hovr").setSmallIcon(R.drawable.ic_notif).setContentTitle("Hovr is running")
            .addAction(Notification.Action.Builder(null, "Close", stop).build()).build())
        show()
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        val noFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        val yesFocus = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        lp = WindowManager.LayoutParams(dp(300), dp(260), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, noFocus, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(80) }

        fun setFocus(on: Boolean) {
            lp.flags = if (on) yesFocus else noFocus
            wrap?.let { wm.updateViewLayout(it, lp) }
        }

        fun showIme(v: View) {
            v.postDelayed({
                v.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
            }, 250)
        }
        val editableJs = "(function(){var a=document.activeElement;return !!a&&(a.tagName=='INPUT'||a.tagName=='TEXTAREA'||a.isContentEditable)})()"

        val urlBar = EditText(this).apply {
            setSingleLine(); hint = "Search Google or type a link"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            textSize = 13f; setBackgroundColor(Color.parseColor("#22233A")); setPadding(dp(10), 0, dp(10), 0)
            imeOptions = EditorInfo.IME_ACTION_GO; inputType = InputType.TYPE_TEXT_VARIATION_URI
            setOnTouchListener { v, e -> if (e.action == MotionEvent.ACTION_DOWN) { setFocus(true); showIme(v) }; false }
        }

        var uiHidden = false
        var browserTab = false
        // Video-only mode: makes the YouTube player fill the whole window and hides the page around it
        val cssOn = "(function(){var s=document.getElementById('hovr-css');if(!s){s=document.createElement('style');s.id='hovr-css';document.head.appendChild(s);}" +
            "s.textContent='#player-container-id{position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;z-index:2147483646!important;background:#000!important}" +
            "#player-container-id #player,#player-container-id .html5-video-player,#player-container-id video{width:100%!important;height:100%!important}body{overflow:hidden!important}';" +
            "window.dispatchEvent(new Event('resize'));})()"
        val cssOff = "(function(){var s=document.getElementById('hovr-css');if(s)s.remove();window.dispatchEvent(new Event('resize'));})()"

        val chrome = object : WebChromeClient() {
            override fun onShowCustomView(v: View?, cb: WebChromeClient.CustomViewCallback?) {
                if (v == null || fsView != null) { cb?.onCustomViewHidden(); return }
                fsView = v; fsCb = cb
                saved = intArrayOf(lp.x, lp.y, lp.width, lp.height)
                lp.x = 0; lp.y = 0; lp.width = -1; lp.height = -1
                v.setBackgroundColor(Color.BLACK)
                wrap?.addView(v, FrameLayout.LayoutParams(-1, -1))
                onUi?.invoke()
                wrap?.let { wm.updateViewLayout(it, lp) }
            }
            override fun onHideCustomView() {
                fsView?.let { wrap?.removeView(it) }
                fsView = null; fsCb?.onCustomViewHidden(); fsCb = null
                lp.x = saved[0]; lp.y = saved[1]; lp.width = saved[2]; lp.height = saved[3]
                onUi?.invoke()
                wrap?.let { wm.updateViewLayout(it, lp) }
            }
        }

        fun newWeb(start: String, onUrl: ((String) -> Unit)?) = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            CookieManager.getInstance().setAcceptCookie(true)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(v: WebView, u: String, f: Bitmap?) { onUrl?.invoke(u) }
                override fun onPageFinished(v: WebView, u: String) { if (uiHidden && v === yt) v.evaluateJavascript(cssOn, null) }
            }
            webChromeClient = chrome
            val self = this
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    for (t in longArrayOf(200, 700)) self.postDelayed({
                        self.evaluateJavascript(editableJs) { r -> if (r == "true" && lp.flags == noFocus) { setFocus(true); showIme(self) } }
                    }, t)
                }
                false
            }
            loadUrl(start)
        }
        val ytv = newWeb("https://m.youtube.com", null).also { yt = it }
        val brv = newWeb("https://www.google.com") { u -> if (!urlBar.hasFocus()) urlBar.setText(u) }.also { br = it }
        brv.visibility = View.INVISIBLE
        var cur: WebView = ytv

        val webArea = FrameLayout(this).apply {
            addView(ytv, FrameLayout.LayoutParams(-1, -1)); addView(brv, FrameLayout.LayoutParams(-1, -1))
        }

        fun go(q: String) {
            val s = q.trim(); if (s.isEmpty()) return
            val url = when {
                s.startsWith("http://") || s.startsWith("https://") -> s
                s.contains(".") && !s.contains(" ") -> "https://$s"
                else -> "https://www.google.com/search?q=" + Uri.encode(s)
            }
            brv.loadUrl(url)
        }
        urlBar.setOnEditorActionListener { v, _, _ -> go(v.text.toString()); v.clearFocus(); setFocus(false); true }

        fun tv(t: String, onClick: (() -> Unit)?) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; setPadding(dp(12), 0, dp(12), 0)
            onClick?.let { c -> setOnClickListener { c() } }
        }
        val tabYt = tv("▶ YouTube", null); val tabBr = tv("🌐 Browser", null)
        fun select(browser: Boolean) {
            browserTab = browser
            cur = if (browser) brv else ytv
            ytv.visibility = if (browser) View.INVISIBLE else View.VISIBLE
            brv.visibility = if (browser) View.VISIBLE else View.INVISIBLE
            tabYt.setBackgroundColor(if (browser) Color.TRANSPARENT else Color.parseColor("#44FFFFFF"))
            tabBr.setBackgroundColor(if (browser) Color.parseColor("#44FFFFFF") else Color.TRANSPARENT)
            onUi?.invoke()
        }
        tabYt.setOnClickListener { select(false) }; tabBr.setOnClickListener { select(true) }

        val label = tv("✥ Hovr", null).apply { layoutParams = LinearLayout.LayoutParams(0, -1, 1f); gravity = Gravity.CENTER_VERTICAL }
        val bar = LinearLayout(this).apply {
            setBackgroundColor(Color.parseColor("#5B2EFF")); gravity = Gravity.CENTER_VERTICAL
            addView(label)
            addView(tv("👁") { uiHidden = true; onUi?.invoke() }, LinearLayout.LayoutParams(-2, -1))
            addView(tv("⌨") {
                val on = lp.flags == noFocus
                setFocus(on)
                if (on) showIme(if (browserTab && !uiHidden) urlBar else cur)
            }, LinearLayout.LayoutParams(-2, -1))
            addView(tv("◐") { wrap?.alpha = if (wrap?.alpha == 1f) 0.6f else 1f }, LinearLayout.LayoutParams(-2, -1))
            addView(tv("✕") { stopSelf() }, LinearLayout.LayoutParams(-2, -1))
        }
        val tabs = LinearLayout(this).apply {
            setBackgroundColor(Color.parseColor("#1A1B2E")); gravity = Gravity.CENTER_VERTICAL
            addView(tabYt, LinearLayout.LayoutParams(-2, -1)); addView(tabBr, LinearLayout.LayoutParams(-2, -1))
            addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
            addView(tv("◀") { if (cur.canGoBack()) cur.goBack() }, LinearLayout.LayoutParams(-2, -1))
            addView(tv("↗") { cur.url?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }, LinearLayout.LayoutParams(-2, -1))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK)
            addView(bar, LinearLayout.LayoutParams(-1, dp(38)))
            addView(tabs, LinearLayout.LayoutParams(-1, dp(34)))
            addView(urlBar, LinearLayout.LayoutParams(-1, dp(36)))
            addView(webArea, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        colV = col
        val grip = tv("◢", null).apply { setBackgroundColor(Color.parseColor("#995B2EFF")) }
        val chipMove = tv("✥", null).apply { setBackgroundColor(Color.parseColor("#66000000")); setPadding(0, 0, 0, 0); visibility = View.GONE }
        val chipShow = tv("👁") { uiHidden = false; onUi?.invoke() }.apply { setBackgroundColor(Color.parseColor("#66000000")); setPadding(0, 0, 0, 0); visibility = View.GONE }
        val root = object : FrameLayout(this@FloatService) {
            override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
                super.onWindowFocusChanged(hasWindowFocus)
                if (!hasWindowFocus && lp.flags != noFocus) { lp.flags = noFocus; wm.updateViewLayout(this, lp) }
            }
        }.apply {
            addView(col, FrameLayout.LayoutParams(-1, -1))
            addView(grip, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.END))
            addView(chipMove, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.TOP or Gravity.START))
            addView(chipShow, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.TOP or Gravity.END))
        }
        wrap = root

        // keeps the video playing while moving / resizing (the page tends to pause on layout changes)
        var wasPlaying = false; var lastTick = 0L
        val isPlayingJs = "(function(){var v=document.querySelector('video');return !!(v&&!v.paused)})()"
        val resumeJs = "(function(){var v=document.querySelector('video');if(v&&v.paused)v.play()})()"
        fun guardStart() { wasPlaying = false; cur.evaluateJavascript(isPlayingJs) { wasPlaying = it == "true" } }
        fun guardTick() { val n = System.currentTimeMillis(); if (wasPlaying && n - lastTick > 300) { lastTick = n; cur.evaluateJavascript(resumeJs, null) } }
        fun guardEnd() { if (wasPlaying) { cur.evaluateJavascript(resumeJs, null); cur.postDelayed({ cur.evaluateJavascript(resumeJs, null) }, 500) } }

        fun attachDrag(v: View) {
            v.setOnTouchListener(object : View.OnTouchListener {
                var x = 0f; var y = 0f; var px = 0; var py = 0
                override fun onTouch(view: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { x = e.rawX; y = e.rawY; px = lp.x; py = lp.y; guardStart() }
                        MotionEvent.ACTION_MOVE -> { lp.x = px + (e.rawX - x).toInt(); lp.y = py + (e.rawY - y).toInt(); wm.updateViewLayout(root, lp); guardTick() }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> guardEnd()
                    }
                    return true
                }
            })
        }
        attachDrag(label); attachDrag(chipMove)

        grip.setOnTouchListener(object : View.OnTouchListener {
            var x = 0f; var y = 0f; var pw = 0; var ph = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { x = e.rawX; y = e.rawY; pw = lp.width; ph = lp.height; guardStart() }
                    MotionEvent.ACTION_MOVE -> {
                        lp.width = (pw + (e.rawX - x).toInt()).coerceIn(dp(200), sw)
                        lp.height = (ph + (e.rawY - y).toInt()).coerceIn(dp(140), sh)
                        wm.updateViewLayout(root, lp); guardTick()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> guardEnd()
                }
                return true
            }
        })

        onUi = {
            val fs = fsView != null
            col.visibility = if (fs) View.GONE else View.VISIBLE
            val barVis = if (uiHidden) View.GONE else View.VISIBLE
            bar.visibility = barVis; tabs.visibility = barVis
            urlBar.visibility = if (uiHidden || !browserTab) View.GONE else View.VISIBLE
            grip.visibility = if (fs) View.GONE else View.VISIBLE
            grip.alpha = if (uiHidden) 0.4f else 1f
            val chips = if (uiHidden && !fs) View.VISIBLE else View.GONE
            chipMove.visibility = chips; chipShow.visibility = chips
            ytv.evaluateJavascript(if (uiHidden) cssOn else cssOff, null)
        }
        select(false)
        wm.addView(root, lp)
    }

    override fun onDestroy() {
        yt?.destroy(); br?.destroy(); wrap?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
