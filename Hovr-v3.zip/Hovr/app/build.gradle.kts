plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.hovr.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.hovr.app"; minSdk = 24; targetSdk = 34; versionCode = 3; versionName = "1.2" }
    signingConfigs {
        create("hovr") { storeFile = file("hovr.jks"); storePassword = "hovr123"; keyAlias = "hovr"; keyPassword = "hovr123" }
    }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("hovr") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
